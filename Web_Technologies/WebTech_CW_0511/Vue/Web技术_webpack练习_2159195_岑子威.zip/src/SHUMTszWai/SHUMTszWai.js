import './style.css';
const greeting = (name) => `Hello, ${name}!`;

export default greeting;
