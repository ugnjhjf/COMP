// vue.config.js
const webpackConfig = require('./webpack.config.js');

module.exports = {
    configureWebpack: webpackConfig
};
